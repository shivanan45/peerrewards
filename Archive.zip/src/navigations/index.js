import {View, Text} from 'react-native';
import React from 'react';
import HomeScreen from '../screens/Home';

const Navigations = () => {
  return <HomeScreen />;
};

export default Navigations;
