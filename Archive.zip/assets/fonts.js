export default {
  PrimaryRegular: 'OpenSans-Regular',
  PrimarySemiBold: 'OpenSans-Medium',
  PrimaryBold: 'OpenSans-ExtraBold',
  // SecondaryFont:'OpenSans-Regular',
  // SemiFont:'Mandali-Regular',
  FontMainHeading: 23,
  FontHeadding: 18,
  FontSubHeadding: 15,
  FontBody: 13,
  FontSmall: 10,
};
