import {View, Text} from 'react-native';
import React from 'react';
import Navigations from './src/navigations';

const App = () => {
  return <Navigations />;
};

export default App;
